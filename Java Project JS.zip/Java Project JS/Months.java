/*
Program Name:Months
Variables/Types: String
Inputs: no
If/else statements: yes
Loops:no
Loop how many times: not applicable
*/

public class Months{
    public static void main(String[] args){
        String[] months=new String[]
        {"January","February","March","April","May",
        "June","July","August","September","October",
        "November","December"};

       if(months[0].contains("r")) {
       	System.out.println(months[0]);
       }if(months[1].contains("r")) {
       	System.out.println(months[1]);
       }if(months[2].contains("r")) {
       	System.out.println(months[2]);
       }if(months[3].contains("r")) {
       	System.out.println(months[3]);
       }if(months[4].contains("r")) {
       	System.out.println(months[4]);
       }if(months[5].contains("r")) {
       	System.out.println(months[5]);
       }if(months[6].contains("r")) {
       	System.out.println(months[6]);
       }if(months[7].contains("r")) {
       	System.out.println(months[7]);
       }if(months[8].contains("r")) {
       	System.out.println(months[8]);
       }if(months[9].contains("r")) {
       	System.out.println(months[9]);
       }if(months[10].contains("r")) {
       	System.out.println(months[10]);
       }if(months[11].contains("r")) {
       	System.out.println(months[11]);
       }

    }
}