/*
Program Name:Lisa
Variables/Types: int,double,String
Inputs: no
If/else statements: no
Loops: yes/no
Loop how many times:not applicable
*/

import java.util.Scanner;

public class Lisa{
    public static void main(String[] args){
    Scanner input=new Scanner(System.in);

	int age=9;
	double height=133.3;
	double weight=27.8;
	String name="Lisa";

	System.out.println(name+" is "+age+" years old and is "+height+" centimetres tall.\n"+name+" weighs "+weight+" kilograms.");

    }
}
